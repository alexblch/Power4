#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <string>
#include "header.hpp"




int main()
{
    int column;
    int win = 0;
    Power *p = new Power();
    p->setName();
    for (int i = 0; i < 2; i++)
    {
        std::cout << p->name[i] << std::endl;
    }
    while (win == 0)
    {
        for (int i = 0; i < 2; i++)
        {
            p->print_tab();
            std::cout << p->name[i] << ", entrez la colonne dans laquelle vous voulez mettre votre pion (entre 0 et 6):" << std::endl;
            std::cin >> column;
            p->tab = p->pose(column, p->tab, i + 1);
            p->verif(p->tab, win);
            if(win != 0)
                break;
            p->print_tab();
        }
    }
    
    p->print_tab();
    p->winner(win);
    return 0;
}