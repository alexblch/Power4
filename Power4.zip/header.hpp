#define NC "\e[0m"
#define RED "\e[0;31m"
#define YELL "\e[0;33m"
#define GRN "\e[0;32m"
#define CYN "\e[0;36m"
#define REDB "\e[41m"

class Power
{
public:
    int player = 2;
    std::string name[2];

    int **tab;
    Power();
    void setName();
    void print_tab();
    int **pose(int column, int **tab, int player);
    int verif(int **tab, int &win);
    void winner(int win);
    ~Power();
};



Power::Power()
{
    tab = new int *[6];
    for (int i{0}; i < 6; i++)
        tab[i] = new int[7];
}

void Power::setName()
{
    for (int i{0}; i < 2; i++)
    {
        std::cout << "Entrez votre nom, joueur numéro " << i + 1 << std::endl;
        getline(std::cin, name[i]);
    }
}

void Power::winner(int win)
{
    if (win == 3)
        std::cout << "Vous êtes malheureusement ex-aeqo." << std::endl;
    for (int i = 1; i < 3; i++)
    {
        if (win == i)
            std::cout << "Bravo à " << name[i - 1] << " pour sa victoire." << std::endl;
    }
}

void Power::print_tab()
{
    system("clear");
    for (int k{0}; k < 7; k++)
    {
        if (k < 6)
            std::cout << k << "   ";
        else
            std::cout << k;
    }
    std::cout << " " << std::endl;
    for (int i{0}; i < 6; i++)
    {
        for (int j{0}; j < 7; j++)
        {
            if (tab[i][j] == 0)
            {
                if (j < 6)
                    std::cout << "  | ";
                else
                    std::cout << " ";
            }
            else
            {
                if (tab[i][j] == 1)
                {
                    if (j < 6)
                        std::cout << YELL << "O" << NC << " | ";
                    else
                        std::cout << YELL << "O" << NC;
                }
                if (tab[i][j] == 2)
                {
                    if (j < 6)
                        std::cout << RED << "O" << NC << " | ";
                    else
                        std::cout << RED << "O" << NC;
                }
            }
        }
        printf("\n");
    }
}

int **Power::pose(int columns, int **tab, int player)
{
    int i = 0;
    while (tab[5 - i][columns] != 0)
    {
        i++;
    }
    tab[5 - i][columns] = player;
    return tab;
}

int Power::verif(int **tab, int &win)
{
    int inc2 = 0;
    // verticale
    int inc = 1;
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 6; j++)
        {
            if (tab[i][j] != 0)
            {
                for (int k = 1; k < 4; k++)
                {
                    if (tab[i][j] == tab[i + k][j])
                        inc++;
                    if (inc == 4)
                    {
                        win = tab[i][j];
                        return win;
                    }
                }
                inc = 1;
            }
        }
    }
    // horizontale
    for (int i = 0; i < 6; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            if (tab[i][j] != 0)
            {
                for (int k = 1; k < 4; k++)
                {
                    if (tab[i][j] == tab[i][j + k])
                        inc++;
                    if (inc == 4)
                    {
                        win = tab[i][j];
                        return win;
                    }
                }
                inc = 1;
            }
        }
    }
    // diagonale gauche
    for (int i = 3; i < 6; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            if (tab[i][j] != 0)
            {
                if (tab[i][j] == tab[i - 1][j + 1])
                {
                    if (tab[i][j] == tab[i - 2][j + 2])
                    {
                        if (tab[i][j] == tab[i - 3][j + 3])
                        {
                            win = tab[i][j];
                            return win;
                        }
                    }
                }
                inc = 1;
            }
        }
    }
    // diagonale droite
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            if (tab[i][j] != 0)
            {
                if (tab[i][j] == tab[i + 1][j + 1])
                {
                    if (tab[i][j] == tab[i + 2][j + 2])
                    {
                        if (tab[i][j] == tab[i + 3][j + 3])
                        {
                            win = tab[i][j];
                            return win;
                        }
                    }
                }
                inc = 1;
            }
        }
    }
    // plus de place
    for (int i = 0; i < 6; i++)
    {
        for (int j = 0; j < 7; j++)
        {
            if (tab[i][j] == 1 || tab[i][j] == 2)
                inc2++;
        }
    }
    if (inc2 == 42)
    {
        win = 3;
    }
    return win;
}

Power::~Power()
{
    free(tab);
}
